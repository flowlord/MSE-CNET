#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
# Copyright 2019-2022 by Motion Kerling. All Rights Reserved.
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose and without fee is hereby granted,
# provided that the above copyright notice appear in all copies and that
# both that copyright notice and this permission notice appear in
# supporting documentation, and that the name of Motion Kerling
# not be used in advertising or publicity pertaining to distribution
# of the software without specific, written prior permission.
# Motion Kerling DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
# ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
# Motion Kerling BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
# ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER
# IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT
# OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.


	███╗   ███╗  ██████╗ ███████╗
	████╗ ████║ ██╔════╝ ██╔════╝
	██╔████╔██║ ╚█████╗  █████╗
	██║╚██╔╝██║  ╚═══██╗ ██╔══╝
	██║ ╚═╝ ██║ ██████╔╝ ███████╗
	╚═╝     ╚═╝ ╚═════╝  ╚══════╝
	
	MSE (multiple substitution encryption)

	Créer le mardi 22 janvier 2019 à 01:10 

"""

__author__  = "BloomBerG"
__version__ = "9.0"
__date__    = "20 mai 2023"

from random import randint
from pyperclip import copy

from bloc_a import complexifier,complexifier_inv
from bloc_b import cipher,decipher
from bloc_c import ajout_carac_b,enleve_carac_b

from configs.init import*

import sys


def mse_cipher(msg):
	"""
	|A| --> |B| --> |C|
	"""
	a  = complexifier(msg)
	b = cipher(a)
	c = ajout_carac_b(b,randint(mini,maxi))
	
	open("ct.txt", "w",encoding="utf-8").write(c)


def mse_decipher():
	"""
	|C| --> |B| --> |A|
	"""

	msg = open("ct.txt", "r",encoding="utf-8").readlines()[0]

	c = enleve_carac_b(msg)
	b = decipher(c)
	a = complexifier_inv(b)

	print(a)
	


if __name__ == '__main__':
	if sys.argv[1] == "c":
		mse_cipher(sys.argv[2])
	elif sys.argv[1] == "d":
		mse_decipher()


